vsearch is used to find common letters between the two sequences
